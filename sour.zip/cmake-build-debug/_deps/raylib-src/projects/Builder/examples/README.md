Open `meson.build` with Builder or run `meson build; cd build; ninja; ./core_basic_window` on the commandline to launch the example.
